import java.awt.*;
import java.awt.geom.Ellipse2D;
import javax.swing.JComponent;
class ShapeDrawing extends JComponent {
  
    public void paint(Graphics g)
    {
        Bomba b = new Bomba();
        super.paintComponent(g);
        b.paint(g);


        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLUE);
        g2.fillRect(0, 0, 10000, 10000);
        g2.setColor(new Color(10 , 150 ,0));
        g2.fillRect(0, 500, 600, 100);
        g2.setColor(new Color(215, 215 ,215));
      g2.fillOval(150, 20, 100, 100);
      g2.fillOval(200, 30, 100, 100);
      g2.fillOval(100, 25, 75, 75);
      g2.fillOval(90, 15, 100, 75);
      g2.fillOval(210, 60, 100, 75);

      g2.fillOval(270, 20, 100, 100);
      g2.fillOval(230, 30, 100, 100);
      g2.fillOval(220, 25, 75, 75);
      g2.fillOval(200, 15, 100, 75);
      g2.fillOval(300, 60, 100, 75);
      g2.setColor(new Color(180, 180 ,180));
      g2.fillOval(0, 140, 100, 75);
      g2.drawOval(20, 150, 20, 20);
      g2.setColor(Color.YELLOW);
      g2.drawString("*", 143, 200);
      g2.drawString("*", 23, 20);
      g2.drawString("*", 73, 100);
      g2.drawString("*", 200, 150);
      g2.drawString("*", 133, 300);
      g2.drawString("*", 243, 230);
      g2.drawString("*", 30, 250);
      g2.drawString("*", 243, 230);
      g2.drawString("*", 243, 230);

        int x = 100;
        int y = 100;
        int width = 10;
        int height =10;
        int[] xPoints = {x, x + width / 2, x + width};
        int[] yPoints = {y + height / 2, y - 35, y + height / 2};
        g2.setColor(new Color(227, 0, 0));
        g2.fillPolygon(xPoints, yPoints, 3);
        g2.setColor(Color.ORANGE);
        g2.fill(new Ellipse2D.Double(x, y, width, height));
        g2.setColor(Color.orange);
        g2.fill(new Ellipse2D.Double(x + 10, y + 10, width - 20, height - 20));

      
    }
}
