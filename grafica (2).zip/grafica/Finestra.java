import javax.swing.*;

class Finestra {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Falling bombs");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 600);
        frame.getContentPane().add(new ShapeDrawing ());
        frame.setVisible(true);
    }
}
