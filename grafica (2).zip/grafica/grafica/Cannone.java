import java.awt.*;

public class Cannone {
    public void paint(Graphics g)
    {
        Graphics2D g1 = (Graphics2D) g;


    }
}
