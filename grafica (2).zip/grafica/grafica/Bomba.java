import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Bomba {
     public void paint(Graphics g)
    {
        Graphics2D g1 = (Graphics2D) g;
        g1.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int x = 100;
        int y = 200;
        int width = 50;
        int height = 50;
        int[] xPoints = {x, x + width / 2, x + width};
        int[] yPoints = {y + height / 2, y - 60, y + height / 2};
        g1.setColor(new Color(255, 69, 0));
        g1.fillPolygon(xPoints, yPoints, 3);
        g1.setColor(Color.ORANGE);
        g1.fill(new Ellipse2D.Double(x, y, width, height));
        g1.setColor(Color.yellow);
        g1.fill(new Ellipse2D.Double(x + 10, y + 10, width - 20, height - 20));

    }
}
