import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class DrawPanel extends JPanel {

    private BufferedImage canvas;

    public DrawPanel() {
        canvas = new BufferedImage(10000, 5000, BufferedImage.TYPE_INT_ARGB);
    }

    public synchronized Graphics2D getCanvasGraphics() {
        return canvas.createGraphics();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(canvas, 0, 0, null);
    }
}