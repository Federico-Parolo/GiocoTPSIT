# Task: Draw a bomb with Swing and integrate falling animation

## Completed Steps
- [x] Step 1: Implement Bomba.java with paint method for bomb design and basic physics (position, velocity).
- [x] Step 2: Update ShapeDrawing.java to instantiate multiple Bomba objects, handle animation loop (move, repaint), background, ground collision with explosion.

## Pending Steps
- [ ] Step 3: Test compilation and run (`javac *.java && java Finestra`), verify bombs fall and look good.
- [ ] Step 4: Attempt completion.

Progress will be updated after each step.



