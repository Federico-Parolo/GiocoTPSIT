import java.awt.*;
import javax.swing.JComponent;
class ShapeDrawing extends JComponent {
  
    public void paint(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLUE);
        g2.fillRect(0, 0, 10000, 10000);
        g2.setColor(new Color(10 , 150 ,0));
        g2.fillRect(0, 500, 600, 100);
        g2.setColor(new Color(215, 215 ,215));
      g2.fillOval(150, 20, 100, 100);
      g2.fillOval(200, 30, 100, 100);
      g2.fillOval(100, 25, 75, 75);
      g2.fillOval(90, 15, 100, 75);
      g2.fillOval(210, 60, 100, 75);

      g2.fillOval(270, 20, 100, 100);
      g2.fillOval(230, 30, 100, 100);
      g2.fillOval(220, 25, 75, 75);
      g2.fillOval(200, 15, 100, 75);
      g2.fillOval(300, 60, 100, 75);
      g2.setColor(new Color(180, 180 ,180));
      g2.fillOval(0, 140, 100, 75);
      g2.drawOval(20, 150, 20, 20);
      g2.setColor(Color.YELLOW);
      g2.drawString("*", 143, 200);
      g2.drawString("*", 23, 20);
      g2.drawString("*", 73, 100);
      g2.drawString("*", 200, 150);
      g2.drawString("*", 133, 300);
      g2.drawString("*", 243, 230);
      g2.drawString("*", 30, 250);
      g2.drawString("*", 243, 230);
      g2.drawString("*", 243, 230);

      
    }
}
